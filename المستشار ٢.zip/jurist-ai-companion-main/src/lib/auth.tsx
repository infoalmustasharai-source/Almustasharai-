import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface User {
  id: string;
  name: string;
  email: string;
  role: "admin" | "user" | "contributor";
  credits: number;
  createdAt: string;
}

export interface Analysis {
  id: string;
  userId: string;
  personality: string;
  personalityTitle: string;
  fileName?: string;
  query: string;
  results: string;
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  register: (name: string, email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  analyses: Analysis[];
  addAnalysis: (analysis: Omit<Analysis, "id" | "userId" | "createdAt">) => void;
  useCredit: () => boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

const USERS_KEY = "almustashar_users";
const SESSION_KEY = "almustashar_session";
const ANALYSES_KEY = "almustashar_analyses";

function getStoredUsers(): (User & { password: string })[] {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
  } catch { return []; }
}

function getStoredAnalyses(): Analysis[] {
  try {
    return JSON.parse(localStorage.getItem(ANALYSES_KEY) || "[]");
  } catch { return []; }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [analyses, setAnalyses] = useState<Analysis[]>([]);

  useEffect(() => {
    const sessionEmail = localStorage.getItem(SESSION_KEY);
    if (sessionEmail) {
      const users = getStoredUsers();
      const found = users.find(u => u.email === sessionEmail);
      if (found) {
        const { password: _, ...userData } = found;
        setUser(userData);
        setAnalyses(getStoredAnalyses().filter(a => a.userId === found.id));
      }
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string) => {
    const users = getStoredUsers();
    const found = users.find(u => u.email === email && u.password === password);
    if (!found) return { success: false, error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" };
    const { password: _, ...userData } = found;
    setUser(userData);
    setAnalyses(getStoredAnalyses().filter(a => a.userId === found.id));
    localStorage.setItem(SESSION_KEY, email);
    return { success: true };
  };

  const register = async (name: string, email: string, password: string) => {
    const users = getStoredUsers();
    if (users.find(u => u.email === email)) {
      return { success: false, error: "هذا البريد الإلكتروني مسجل بالفعل" };
    }
    const isAdmin = email === "bishoysamy390@gmail.com";
    const newUser = {
      id: crypto.randomUUID(),
      name,
      email,
      password,
      role: isAdmin ? "admin" as const : "user" as const,
      credits: 3,
      createdAt: new Date().toISOString(),
    };
    users.push(newUser);
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    const { password: _, ...userData } = newUser;
    setUser(userData);
    localStorage.setItem(SESSION_KEY, email);
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    setAnalyses([]);
    localStorage.removeItem(SESSION_KEY);
  };

  const addAnalysis = (analysis: Omit<Analysis, "id" | "userId" | "createdAt">) => {
    if (!user) return;
    const newAnalysis: Analysis = {
      ...analysis,
      id: crypto.randomUUID(),
      userId: user.id,
      createdAt: new Date().toISOString(),
    };
    const allAnalyses = [...getStoredAnalyses(), newAnalysis];
    localStorage.setItem(ANALYSES_KEY, JSON.stringify(allAnalyses));
    setAnalyses(prev => [...prev, newAnalysis]);
  };

  const useCredit = () => {
    if (!user || user.credits <= 0) return false;
    const users = getStoredUsers();
    const idx = users.findIndex(u => u.id === user.id);
    if (idx >= 0) {
      users[idx].credits -= 1;
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
      setUser(prev => prev ? { ...prev, credits: prev.credits - 1 } : null);
    }
    return true;
  };

  return (
    <AuthContext.Provider value={{ user, isLoading, login, register, logout, analyses, addAnalysis, useCredit }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
