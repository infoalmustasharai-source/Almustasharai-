import { cn } from "@/lib/utils";

interface PersonalityCardProps {
  icon: string;
  title: string;
  description: string;
  features: string[];
  onClick: () => void;
  delay?: number;
}

const PersonalityCard = ({ icon, title, description, features, onClick, delay = 0 }: PersonalityCardProps) => {
  return (
    <button
      onClick={onClick}
      className={cn(
        "group relative w-full text-right p-6 rounded-xl",
        "bg-card border border-border hover:border-gold/40",
        "transition-all duration-500 hover:shadow-gold hover:-translate-y-1",
        "animate-fade-in-up opacity-0"
      )}
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Glow effect on hover */}
      <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      
      <div className="relative z-10">
        <div className="text-4xl mb-4">{icon}</div>
        <h3 className="text-xl font-bold font-cairo text-foreground mb-2 group-hover:text-gradient-gold transition-colors">
          {title}
        </h3>
        <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
          {description}
        </p>
        <ul className="space-y-2">
          {features.map((feature, i) => (
            <li key={i} className="flex items-center gap-2 text-xs text-muted-foreground">
              <span className="w-1 h-1 rounded-full bg-primary flex-shrink-0" />
              {feature}
            </li>
          ))}
        </ul>
        
        <div className="mt-5 flex items-center gap-2 text-primary text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
          <span>ابدأ الآن</span>
          <svg className="w-4 h-4 rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
          </svg>
        </div>
      </div>
    </button>
  );
};

export default PersonalityCard;
