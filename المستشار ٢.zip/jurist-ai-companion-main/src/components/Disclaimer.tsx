import { AlertTriangle } from "lucide-react";

const Disclaimer = () => (
  <div className="w-full border-t border-border bg-card/50 py-4 px-6">
    <div className="max-w-4xl mx-auto flex items-start gap-3 text-xs text-muted-foreground leading-relaxed">
      <AlertTriangle className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
      <p>
        ⚠️ إخلاء مسؤولية: "المستشار AI" أداة مساعدة بالذكاء الاصطناعي ولا تغني عن الاستشارة القانونية المتخصصة. التحليلات المقدمة أولية وليست رأياً قانونياً ملزماً.
      </p>
    </div>
  </div>
);

export default Disclaimer;
