import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/lib/auth";
import ProtectedRoute from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Consultant from "./pages/Consultant";
import Defense from "./pages/Defense";
import Judge from "./pages/Judge";
import Analyst from "./pages/Analyst";
import Chat from "./pages/Chat";
import AdminPanel from "./pages/AdminPanel";
import Pricing from "./pages/Pricing";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/pricing" element={<Pricing />} />
            <Route path="/register" element={<Register />} />
            <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
            <Route path="/consultant" element={<ProtectedRoute><Consultant /></ProtectedRoute>} />
            <Route path="/defense" element={<ProtectedRoute><Defense /></ProtectedRoute>} />
            <Route path="/judge" element={<ProtectedRoute><Judge /></ProtectedRoute>} />
            <Route path="/analyst" element={<ProtectedRoute><Analyst /></ProtectedRoute>} />
            <Route path="/chat/:personalityId" element={<ProtectedRoute><Chat /></ProtectedRoute>} />
            <Route path="/admin" element={<ProtectedRoute adminOnly><AdminPanel /></ProtectedRoute>} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
