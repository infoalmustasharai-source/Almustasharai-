import { useNavigate, Link } from "react-router-dom";
import { Scale, Shield, Sparkles, Settings, LogIn, LayoutDashboard, Star, Users, FileText, ArrowLeft, MessageCircle, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import PersonalityCard from "@/components/PersonalityCard";
import Disclaimer from "@/components/Disclaimer";
import { personalities } from "@/lib/personalities";
import { useAuth } from "@/lib/auth";
import { useEffect, useState } from "react";

const Index = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [showChatbot, setShowChatbot] = useState(false);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-dark">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Scale className="w-5 h-5 text-background" />
            </div>
            <div>
              <h1 className="text-lg font-bold font-cairo text-foreground">المستشار AI</h1>
              <p className="text-xs text-muted-foreground">مستشارك القانوني الذكي</p>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            <Link to="/pricing" className="text-xs sm:text-sm text-muted-foreground hover:text-primary transition-colors font-medium">
              الأسعار
            </Link>
            {user ? (
              <>
                {user.role === "admin" && (
                  <Link to="/admin" className="p-2 rounded-lg hover:bg-secondary transition-colors" title="لوحة الإدارة">
                    <Settings className="w-4 h-4 text-muted-foreground hover:text-primary transition-colors" />
                  </Link>
                )}
                <Link to="/dashboard" className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-primary/10 border border-primary/20 hover:bg-primary/20 transition-colors">
                  <LayoutDashboard className="w-4 h-4 text-primary" />
                  <span className="text-xs text-primary font-semibold hidden sm:inline">لوحة التحكم</span>
                </Link>
              </>
            ) : (
              <Link to="/login" className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gradient-gold text-background text-sm font-semibold hover:opacity-90 transition-opacity">
                <LogIn className="w-4 h-4" />
                <span className="hidden sm:inline">دخول</span>
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 opacity-20">
          <div className="absolute top-20 right-10 w-72 h-72 bg-primary/20 rounded-full blur-3xl" />
          <div className="absolute bottom-20 left-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        </div>
        <div className="max-w-6xl mx-auto px-4 py-16 md:py-24 relative">
          <div className="text-center mb-14 animate-fade-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-secondary border border-border mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm text-secondary-foreground">مدعوم بالذكاء الاصطناعي المتقدم</span>
            </div>
            <h2 className="text-4xl md:text-6xl font-bold font-cairo mb-6 leading-tight">
              <span className="text-foreground">مستشارك القانوني</span>
              <br />
              <span className="text-gradient-gold">بالذكاء الاصطناعي</span>
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto leading-relaxed text-lg md:text-xl mb-8">
              تحليل العقود، صياغة المذكرات، محاكاة المحاكم، والبحث القانوني — كل ذلك بدقة متناهية ومستنداً إلى القانون المصري.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Button
                onClick={() => navigate(user ? "/dashboard" : "/register")}
                className="bg-gradient-gold text-background font-semibold text-lg px-8 py-6 hover:opacity-90"
              >
                {user ? "ابدأ التحليل" : "ابدأ مجاناً — ٣ تحليلات"}
                <ArrowLeft className="w-5 h-5 mr-2" />
              </Button>
              <Button
                variant="outline"
                onClick={() => navigate("/pricing")}
                className="text-lg px-8 py-6 border-border hover:border-primary/30"
              >
                عرض الباقات
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Personality Grid */}
      <section className="py-12 md:py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h3 className="text-2xl md:text-3xl font-bold font-cairo text-foreground text-center mb-10">
            أربع شخصيات قانونية متخصصة
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5 max-w-4xl mx-auto">
            {personalities.map((p, i) => (
              <PersonalityCard
                key={p.id}
                icon={p.icon}
                title={p.title}
                description={p.description}
                features={p.features}
                onClick={() => {
                  if (user) {
                    const routes: Record<string, string> = { consultant: "/consultant", defense: "/defense", judge: "/judge", analyst: "/analyst" };
                    navigate(routes[p.id] || `/chat/${p.id}`);
                  } else {
                    navigate("/login");
                  }
                }}
                delay={i * 150}
              />
            ))}
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-12 md:py-16 border-t border-border">
        <div className="max-w-6xl mx-auto px-4">
          <h3 className="text-2xl md:text-3xl font-bold font-cairo text-foreground text-center mb-10">
            كيف يعمل المستشار AI؟
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { step: "١", title: "اختر الشخصية", desc: "اختر من بين ٤ شخصيات قانونية متخصصة حسب احتياجك", icon: <Users className="w-6 h-6" /> },
              { step: "٢", title: "أدخل بياناتك", desc: "اكتب النص أو ارفع الملف أو التقط صورة للمستند", icon: <FileText className="w-6 h-6" /> },
              { step: "٣", title: "احصل على التحليل", desc: "تحليل فوري ومفصل مستند إلى القانون المصري", icon: <CheckCircle className="w-6 h-6" /> },
            ].map((item, i) => (
              <div key={item.step} className="text-center p-6 rounded-xl bg-card border border-border animate-fade-in-up" style={{ animationDelay: `${i * 200}ms` }}>
                <div className="w-14 h-14 rounded-full bg-primary/10 border-2 border-primary/30 flex items-center justify-center mx-auto mb-4">
                  <span className="text-primary">{item.icon}</span>
                </div>
                <div className="text-xs text-primary font-bold mb-2">الخطوة {item.step}</div>
                <h4 className="text-lg font-bold font-cairo text-foreground mb-2">{item.title}</h4>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-12 md:py-16 border-t border-border">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto text-center">
            {[
              { value: "٤", label: "شخصيات متخصصة" },
              { value: "٢٤/٧", label: "متاح دائماً" },
              { value: "مصري", label: "قانون متخصص" },
              { value: "مجاني", label: "ابدأ الآن" },
            ].map((stat, i) => (
              <div key={stat.label} className="animate-fade-in-up" style={{ animationDelay: `${i * 100}ms` }}>
                <div className="text-3xl font-bold text-gradient-gold font-cairo">{stat.value}</div>
                <div className="text-sm text-muted-foreground mt-2">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-12 md:py-16 border-t border-border">
        <div className="max-w-6xl mx-auto px-4">
          <h3 className="text-2xl md:text-3xl font-bold font-cairo text-foreground text-center mb-10">
            آراء المستخدمين
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {[
              { name: "أ. أحمد محمود", role: "محامي حر", text: "وفّر علي ساعات من البحث القانوني. التحليل دقيق ومستند للقانون المصري.", rating: 5 },
              { name: "أ. سارة علي", role: "مستشارة قانونية", text: "أداة رائعة لصياغة المذكرات. الاقتراحات البديلة مفيدة جداً.", rating: 5 },
              { name: "أ. محمد حسن", role: "طالب قانون", text: "ساعدني في فهم القضايا بشكل أعمق. واجهة سهلة وبسيطة.", rating: 4 },
            ].map((t, i) => (
              <div key={t.name} className="p-5 rounded-xl bg-card border border-border animate-fade-in-up" style={{ animationDelay: `${i * 150}ms` }}>
                <div className="flex gap-1 mb-3">
                  {Array.from({ length: t.rating }).map((_, j) => (
                    <Star key={j} className="w-4 h-4 text-primary fill-primary" />
                  ))}
                </div>
                <p className="text-sm text-foreground mb-4 leading-relaxed">"{t.text}"</p>
                <div>
                  <p className="text-sm font-bold text-foreground">{t.name}</p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 border-t border-border">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h3 className="text-2xl md:text-3xl font-bold font-cairo text-foreground mb-4">
            جاهز لتجربة المستشار AI؟
          </h3>
          <p className="text-muted-foreground mb-8 max-w-lg mx-auto">
            سجل الآن واحصل على ٣ تحليلات مجانية. لا حاجة لبطاقة ائتمان.
          </p>
          <Button
            onClick={() => navigate(user ? "/dashboard" : "/register")}
            className="bg-gradient-gold text-background font-semibold text-lg px-10 py-6 hover:opacity-90"
          >
            {user ? "ابدأ التحليل" : "ابدأ مجاناً الآن"}
          </Button>
        </div>
      </section>

      <Disclaimer />

      {/* AIBotKit Chatbot Widget */}
      <button
        onClick={() => setShowChatbot(!showChatbot)}
        className="fixed bottom-6 left-6 z-50 w-14 h-14 rounded-full bg-gradient-gold text-background shadow-gold flex items-center justify-center hover:opacity-90 transition-opacity"
        title="المساعد الذكي"
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {showChatbot && (
        <div className="fixed bottom-24 left-6 z-50 w-[360px] h-[500px] rounded-2xl overflow-hidden shadow-2xl border border-border animate-fade-in-up">
          <iframe
            src="https://app.aibotkit.io/chatbot/50668107-57e8-44"
            width="100%"
            height="100%"
            style={{ border: "none" }}
            title="المساعد الذكي - المستشار AI"
          />
        </div>
      )}
    </div>
  );
};

export default Index;
