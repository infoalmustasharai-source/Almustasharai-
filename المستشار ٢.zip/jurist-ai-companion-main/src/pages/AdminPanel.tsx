import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Scale, FileText, Users, BarChart3, Upload, Trash2, RefreshCw, Search, Shield, BookOpen, Gavel, FileCheck } from "lucide-react";
import Disclaimer from "@/components/Disclaimer";

// Mock data
const mockDocuments = [
  { id: "1", title: "القانون المدني المصري", category: "قوانين أساسية", uploadedAt: "2025-01-15", size: "2.4 MB", status: "مفهرس" },
  { id: "2", title: "قانون العقوبات", category: "قوانين أساسية", uploadedAt: "2025-01-16", size: "1.8 MB", status: "مفهرس" },
  { id: "3", title: "قانون الإجراءات الجنائية", category: "قوانين أساسية", uploadedAt: "2025-01-17", size: "1.2 MB", status: "مفهرس" },
  { id: "4", title: "نموذج عقد إيجار", category: "صيغ قانونية", uploadedAt: "2025-02-01", size: "340 KB", status: "مفهرس" },
  { id: "5", title: "حكم نقض - قضية تعويض", category: "أحكام نقض", uploadedAt: "2025-02-05", size: "520 KB", status: "قيد الفهرسة" },
];

const mockUsers = [
  { id: "1", name: "BishoySamy", email: "bishoy@example.com", role: "admin", analyses: 45, joinedAt: "2025-01-01" },
  { id: "2", name: "أحمد محمود", email: "ahmed@example.com", role: "user", analyses: 12, joinedAt: "2025-01-20" },
  { id: "3", name: "سارة علي", email: "sara@example.com", role: "contributor", analyses: 28, joinedAt: "2025-02-01" },
  { id: "4", name: "محمد حسن", email: "mohamed@example.com", role: "user", analyses: 8, joinedAt: "2025-02-15" },
  { id: "5", name: "نورا إبراهيم", email: "noura@example.com", role: "user", analyses: 15, joinedAt: "2025-03-01" },
];

const categories = ["قوانين أساسية", "أحكام نقض", "صيغ قانونية", "استراتيجيات تقاضي", "أخرى"];

const roleLabels: Record<string, string> = {
  admin: "مالك",
  user: "مستخدم",
  contributor: "مساهم",
};

const roleBadgeClasses: Record<string, string> = {
  admin: "bg-primary/20 text-primary border-primary/30",
  contributor: "bg-accent/20 text-accent border-accent/30",
  user: "bg-secondary text-secondary-foreground border-border",
};

type Tab = "documents" | "users" | "stats";

const AdminPanel = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<Tab>("documents");
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("الكل");

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: "documents", label: "الملفات القانونية", icon: <FileText className="w-4 h-4" /> },
    { id: "users", label: "المستخدمون", icon: <Users className="w-4 h-4" /> },
    { id: "stats", label: "الإحصائيات", icon: <BarChart3 className="w-4 h-4" /> },
  ];

  const filteredDocs = mockDocuments.filter((doc) => {
    const matchesSearch = doc.title.includes(searchQuery);
    const matchesCategory = selectedCategory === "الكل" || doc.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="min-h-screen flex flex-col bg-gradient-dark">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/")} className="p-2 rounded-lg hover:bg-secondary transition-colors">
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <div className="w-9 h-9 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Scale className="w-4 h-4 text-background" />
            </div>
            <div>
              <h1 className="font-bold font-cairo text-foreground">لوحة تحكم المالك</h1>
              <p className="text-xs text-muted-foreground">المستشار AI - إدارة النظام</p>
            </div>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20">
            <Shield className="w-3.5 h-3.5 text-primary" />
            <span className="text-xs text-primary font-semibold">Admin</span>
          </div>
        </div>
      </header>

      <div className="flex-1">
        <div className="max-w-6xl mx-auto px-4 py-6">
          {/* Tabs */}
          <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all whitespace-nowrap ${
                  activeTab === tab.id
                    ? "bg-primary text-primary-foreground shadow-gold"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80 border border-border"
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>

          {/* Documents Tab */}
          {activeTab === "documents" && (
            <div className="space-y-4 animate-fade-in-up">
              {/* Actions Bar */}
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="flex-1 relative">
                  <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="البحث في الملفات..."
                    className="w-full pr-10 pl-4 py-2.5 rounded-lg bg-secondary border border-border text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                  />
                </div>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="px-4 py-2.5 rounded-lg bg-secondary border border-border text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                >
                  <option value="الكل">كل التصنيفات</option>
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
                <button className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-gold text-background text-sm font-semibold hover:opacity-90 transition-opacity">
                  <Upload className="w-4 h-4" />
                  رفع ملف
                </button>
                <button className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-secondary border border-border text-sm text-secondary-foreground hover:bg-secondary/80 transition-colors">
                  <RefreshCw className="w-4 h-4" />
                  إعادة فهرسة
                </button>
              </div>

              {/* Documents Table */}
              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-secondary/50">
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium">العنوان</th>
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium hidden sm:table-cell">التصنيف</th>
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium hidden md:table-cell">الحجم</th>
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium hidden md:table-cell">الحالة</th>
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredDocs.map((doc) => (
                        <tr key={doc.id} className="border-b border-border last:border-0 hover:bg-secondary/30 transition-colors">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <FileText className="w-4 h-4 text-primary flex-shrink-0" />
                              <span className="text-foreground font-medium">{doc.title}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell">{doc.category}</td>
                          <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{doc.size}</td>
                          <td className="px-4 py-3 hidden md:table-cell">
                            <span className={`inline-flex px-2 py-0.5 rounded-full text-xs ${
                              doc.status === "مفهرس" ? "bg-green-500/10 text-green-400 border border-green-500/20" : "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20"
                            }`}>
                              {doc.status}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <button className="p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Users Tab */}
          {activeTab === "users" && (
            <div className="space-y-4 animate-fade-in-up">
              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-secondary/50">
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium">المستخدم</th>
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium hidden sm:table-cell">البريد</th>
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium">الدور</th>
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium hidden md:table-cell">التحليلات</th>
                        <th className="text-right px-4 py-3 text-muted-foreground font-medium hidden md:table-cell">تاريخ الانضمام</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mockUsers.map((user) => (
                        <tr key={user.id} className="border-b border-border last:border-0 hover:bg-secondary/30 transition-colors">
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs font-bold text-foreground">
                                {user.name.charAt(0)}
                              </div>
                              <span className="text-foreground font-medium">{user.name}</span>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-muted-foreground hidden sm:table-cell" dir="ltr">{user.email}</td>
                          <td className="px-4 py-3">
                            <span className={`inline-flex px-2.5 py-0.5 rounded-full text-xs border font-medium ${roleBadgeClasses[user.role]}`}>
                              {roleLabels[user.role]}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-muted-foreground hidden md:table-cell">{user.analyses}</td>
                          <td className="px-4 py-3 text-muted-foreground hidden md:table-cell" dir="ltr">{user.joinedAt}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Stats Tab */}
          {activeTab === "stats" && (
            <div className="space-y-6 animate-fade-in-up">
              {/* Stats Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { icon: <Users className="w-5 h-5" />, label: "المستخدمون", value: "١٢٨", change: "+١٢%" },
                  { icon: <FileText className="w-5 h-5" />, label: "التحليلات", value: "٣٤٥", change: "+٢٥%" },
                  { icon: <BookOpen className="w-5 h-5" />, label: "الملفات القانونية", value: "٤٧", change: "+٨" },
                  { icon: <Gavel className="w-5 h-5" />, label: "أحكام النقض", value: "٥٢", change: "+٣" },
                ].map((stat) => (
                  <div key={stat.label} className="p-4 rounded-xl bg-card border border-border hover:border-gold/30 transition-colors">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-primary">{stat.icon}</span>
                      <span className="text-xs text-green-400 font-medium">{stat.change}</span>
                    </div>
                    <div className="text-2xl font-bold text-foreground font-cairo">{stat.value}</div>
                    <div className="text-xs text-muted-foreground mt-1">{stat.label}</div>
                  </div>
                ))}
              </div>

              {/* Usage Chart Placeholder */}
              <div className="rounded-xl border border-border bg-card p-6">
                <h3 className="text-foreground font-bold font-cairo mb-4">نشاط التحليلات (آخر ٣٠ يوم)</h3>
                <div className="h-48 flex items-end gap-1.5">
                  {Array.from({ length: 30 }, (_, i) => {
                    const height = Math.random() * 80 + 20;
                    return (
                      <div key={i} className="flex-1 rounded-t bg-gradient-gold opacity-60 hover:opacity-100 transition-opacity" style={{ height: `${height}%` }} />
                    );
                  })}
                </div>
                <div className="flex justify-between mt-2 text-xs text-muted-foreground">
                  <span>قبل ٣٠ يوم</span>
                  <span>اليوم</span>
                </div>
              </div>

              {/* Top Personalities */}
              <div className="rounded-xl border border-border bg-card p-6">
                <h3 className="text-foreground font-bold font-cairo mb-4">الشخصيات الأكثر استخداماً</h3>
                <div className="space-y-3">
                  {[
                    { icon: "🧑‍⚖️", name: "محامي استشاري", count: 156, pct: 45 },
                    { icon: "⚖️", name: "محامي دفاع", count: 98, pct: 28 },
                    { icon: "📊", name: "محلل قانوني", count: 58, pct: 17 },
                    { icon: "👨‍⚖️", name: "قاضي افتراضي", count: 33, pct: 10 },
                  ].map((p) => (
                    <div key={p.name} className="flex items-center gap-3">
                      <span className="text-xl">{p.icon}</span>
                      <div className="flex-1">
                        <div className="flex justify-between mb-1">
                          <span className="text-sm text-foreground font-medium">{p.name}</span>
                          <span className="text-xs text-muted-foreground">{p.count} تحليل</span>
                        </div>
                        <div className="h-2 rounded-full bg-secondary overflow-hidden">
                          <div className="h-full rounded-full bg-gradient-gold transition-all" style={{ width: `${p.pct}%` }} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recent Feedback */}
              <div className="rounded-xl border border-border bg-card p-6">
                <h3 className="text-foreground font-bold font-cairo mb-4 flex items-center gap-2">
                  <FileCheck className="w-5 h-5 text-primary" />
                  آخر التقييمات
                </h3>
                <div className="space-y-3">
                  {[
                    { user: "أحمد محمود", rating: "مفيد جداً", comment: "التحليل كان دقيقاً ومفصلاً", time: "منذ ساعة" },
                    { user: "سارة علي", rating: "مفيد", comment: "أحتاج تفاصيل أكثر عن البند الثالث", time: "منذ ٣ ساعات" },
                    { user: "محمد حسن", rating: "مفيد جداً", comment: "ممتاز! وفّر علي وقتاً كبيراً", time: "منذ ٥ ساعات" },
                  ].map((fb, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-secondary/50 border border-border">
                      <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs font-bold text-foreground flex-shrink-0">
                        {fb.user.charAt(0)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-foreground">{fb.user}</span>
                          <span className="text-xs text-muted-foreground">{fb.time}</span>
                        </div>
                        <span className="inline-flex px-2 py-0.5 rounded-full text-xs bg-green-500/10 text-green-400 border border-green-500/20 mb-1">
                          {fb.rating}
                        </span>
                        <p className="text-xs text-muted-foreground">{fb.comment}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <Disclaimer />
    </div>
  );
};

export default AdminPanel;
