import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Scale, Send, Search } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import Disclaimer from "@/components/Disclaimer";

const Analyst = () => {
  const navigate = useNavigate();
  const { user, useCredit, addAnalysis } = useAuth();
  const [query, setQuery] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState("");

  const handleAnalyze = () => {
    if (!query.trim()) return;
    if (!useCredit()) {
      setResult("⚠️ رصيدك منتهي.");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      const mockResult = `📊 نتائج التحليل القانوني\n\nالسؤال: "${query}"\n\n📖 النصوص القانونية ذات الصلة:\n• المادة ١٦٣ من القانون المدني المصري: "كل خطأ سبب ضرراً للغير يلزم من ارتكبه بالتعويض"\n• المادة ١٧٠: للقاضي تقدير التعويض بما يراه جابراً للضرر\n• قانون المرور رقم ٦٦ لسنة ١٩٧٣ وتعديلاته\n\n📈 الاتجاهات القضائية:\n• متوسط التعويضات في حوادث السيارات: ١٥٠,٠٠٠ - ٥٠٠,٠٠٠ جنيه\n• نسبة الأحكام لصالح المتضررين: ٧٨٪\n• متوسط مدة التقاضي: ١٢-١٨ شهر\n\n🌍 مقارنة تشريعية:\n• مصر: نظام المسؤولية التقصيرية مع إمكانية التعويض المادي والأدبي\n• الإمارات: نظام مشابه مع حدود أعلى للتعويضات\n• السعودية: نظام الدية والتعويض وفق الشريعة\n\n📊 إحصائيات:\n• عدد القضايا المماثلة في ٢٠٢٤: ١٢,٥٠٠ قضية\n• معدل التسوية الودية: ٣٥٪\n• نسبة الاستئناف: ٤٢٪\n\n⚠️ هذا تحليل إحصائي أولي وليس استشارة قانونية.`;
      setResult(mockResult);
      addAnalysis({
        personality: "analyst",
        personalityTitle: "محلل قانوني",
        query: query.substring(0, 100),
        results: mockResult,
      });
      setIsLoading(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-dark">
      <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/dashboard")} className="p-2 rounded-lg hover:bg-secondary transition-colors">
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <div className="w-9 h-9 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Scale className="w-4 h-4 text-background" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg">📊</span>
                <h1 className="font-bold font-cairo text-foreground">محلل قانوني</h1>
              </div>
              <p className="text-xs text-muted-foreground">المستشار AI • رصيد: {user?.credits} تحليلات</p>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-4">
          {!result ? (
            <div className="animate-fade-in-up">
              <div className="text-center py-12">
                <div className="text-6xl mb-6">📊</div>
                <h2 className="text-2xl font-bold font-cairo text-foreground mb-3">المحلل القانوني</h2>
                <p className="text-muted-foreground max-w-md mx-auto mb-8">
                  اطرح سؤالك القانوني وسأقوم بالبحث في القوانين والأحكام وتقديم تحليل إحصائي شامل
                </p>
              </div>

              <div className="relative">
                <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") handleAnalyze(); }}
                  placeholder="مثال: ما متوسط التعويضات في حوادث السيارات؟"
                  className="w-full pr-12 pl-4 py-4 rounded-xl bg-secondary border border-border text-base text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                />
              </div>

              <div className="flex flex-wrap gap-2 mt-3">
                {["التعويض عن الفصل التعسفي", "إجراءات الطلاق", "عقوبة خيانة الأمانة", "شروط التحكيم التجاري"].map(s => (
                  <button key={s} onClick={() => setQuery(s)} className="px-3 py-1.5 rounded-full bg-secondary border border-border text-xs text-muted-foreground hover:text-foreground hover:border-primary/30 transition-colors">
                    {s}
                  </button>
                ))}
              </div>

              <Button
                onClick={handleAnalyze}
                disabled={!query.trim() || isLoading}
                className="w-full mt-4 bg-gradient-gold text-background font-semibold h-12"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
                    جارٍ البحث والتحليل...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Search className="w-4 h-4" /> بحث وتحليل
                  </div>
                )}
              </Button>
            </div>
          ) : (
            <div className="animate-fade-in-up">
              <div className="rounded-xl bg-card border border-border p-6">
                <pre className="text-sm text-foreground leading-relaxed whitespace-pre-wrap font-cairo">{result}</pre>
              </div>
              <div className="flex gap-3 mt-4">
                <Button onClick={() => { setResult(""); setQuery(""); }} variant="outline" className="flex-1">سؤال جديد</Button>
                <Button onClick={() => navigate("/dashboard")} className="flex-1 bg-gradient-gold text-background">العودة للوحة التحكم</Button>
              </div>
            </div>
          )}
        </div>
      </div>
      <Disclaimer />
    </div>
  );
};

export default Analyst;
