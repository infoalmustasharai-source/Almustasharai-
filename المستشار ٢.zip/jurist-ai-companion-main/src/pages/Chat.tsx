import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowRight, Send, Upload, Scale } from "lucide-react";
import { personalities } from "@/lib/personalities";
import Disclaimer from "@/components/Disclaimer";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const Chat = () => {
  const { personalityId } = useParams();
  const navigate = useNavigate();
  const personality = personalities.find((p) => p.id === personalityId);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  if (!personality) {
    navigate("/");
    return null;
  }

  const handleSend = () => {
    if (!input.trim()) return;
    const userMsg: Message = { role: "user", content: input.trim() };
    setMessages((prev) => [...prev, userMsg]);
    setInput("");
    setIsLoading(true);

    // Mock AI response (will be replaced with real AI later)
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `شكراً لسؤالك. أنا ${personality.title} وسأساعدك في هذا الأمر.\n\nهذه نسخة تجريبية من التطبيق. عند تفعيل Lovable Cloud والربط بالذكاء الاصطناعي، ستحصل على إجابات قانونية دقيقة مستندة إلى القانون المصري.\n\n⚠️ إخلاء مسؤولية: هذه الإجابة أولية وليست رأياً قانونياً ملزماً.`,
        },
      ]);
      setIsLoading(false);
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-dark">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate("/")}
              className="p-2 rounded-lg hover:bg-secondary transition-colors"
            >
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <div className="w-9 h-9 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Scale className="w-4 h-4 text-background" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg">{personality.icon}</span>
                <h1 className="font-bold font-cairo text-foreground">{personality.title}</h1>
              </div>
              <p className="text-xs text-muted-foreground">المستشار AI</p>
            </div>
          </div>
        </div>
      </header>

      {/* Chat Area */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 py-6">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-20 text-center animate-fade-in-up">
              <div className="text-6xl mb-6">{personality.icon}</div>
              <h2 className="text-2xl font-bold font-cairo text-foreground mb-3">{personality.title}</h2>
              <p className="text-muted-foreground max-w-md leading-relaxed mb-8">
                {personality.description}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-lg w-full">
                {personality.features.map((f, i) => (
                  <div
                    key={i}
                    className="p-3 rounded-lg bg-secondary border border-border text-sm text-secondary-foreground text-right"
                  >
                    {f}
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {messages.map((msg, i) => (
                <div
                  key={i}
                  className={`flex ${msg.role === "user" ? "justify-start" : "justify-end"}`}
                >
                  <div
                    className={`max-w-[85%] rounded-xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary text-secondary-foreground border border-border"
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-end">
                  <div className="bg-secondary border border-border rounded-xl px-4 py-3">
                    <div className="flex gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
                      <span className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: "0.2s" }} />
                      <span className="w-2 h-2 rounded-full bg-primary animate-pulse" style={{ animationDelay: "0.4s" }} />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Input Area */}
      <div className="border-t border-border bg-card/50 backdrop-blur-md p-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex gap-3 items-end">
            {personality.inputType === "file-upload" && (
              <button className="p-3 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors border border-border flex-shrink-0">
                <Upload className="w-5 h-5 text-muted-foreground" />
              </button>
            )}
            <div className="flex-1 relative">
              <textarea
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSend();
                  }
                }}
                placeholder={
                  personality.inputType === "file-upload"
                    ? "أدخل نص العقد أو ارفع ملفاً..."
                    : personality.inputType === "search-box"
                    ? "اطرح سؤالك القانوني..."
                    : "اكتب رسالتك..."
                }
                rows={1}
                className="w-full resize-none rounded-xl bg-secondary border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary/50"
              />
            </div>
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="p-3 rounded-xl bg-gradient-gold text-background font-semibold transition-all hover:opacity-90 disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
            >
              <Send className="w-5 h-5 rotate-180" />
            </button>
          </div>
        </div>
      </div>

      <Disclaimer />
    </div>
  );
};

export default Chat;
