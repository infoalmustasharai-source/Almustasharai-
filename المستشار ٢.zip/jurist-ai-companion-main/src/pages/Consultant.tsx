import { useState, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Scale, Send, Upload, FileText, Camera, X } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import Disclaimer from "@/components/Disclaimer";

const Consultant = () => {
  const navigate = useNavigate();
  const { user, useCredit, addAnalysis } = useAuth();
  const [textInput, setTextInput] = useState("");
  const [fileName, setFileName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState("");
  const [showCamera, setShowCamera] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const startCamera = useCallback(async () => {
    setCameraError("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      setShowCamera(true);
    } catch (err) {
      console.error("Camera error:", err);
      setCameraError("تعذر الوصول للكاميرا. تأكد من إعطاء الإذن.");
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    setShowCamera(false);
  }, []);

  const capturePhoto = useCallback(() => {
    if (!videoRef.current) return;
    const canvas = document.createElement("canvas");
    canvas.width = videoRef.current.videoWidth;
    canvas.height = videoRef.current.videoHeight;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0);
      setFileName("صورة ملتقطة.jpg");
      setTextInput("[محتوى مستخرج من صورة ملتقطة بالكاميرا]\n\nنص تجريبي للعقد يحتوي على بنود متعددة للتحليل...");
    }
    stopCamera();
  }, [stopCamera]);

  const handleAnalyze = (query: string, file?: string) => {
    if (!query.trim()) return;
    if (!useCredit()) {
      setResult("⚠️ رصيدك منتهي. يرجى شراء رصيد إضافي للاستمرار.");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      const mockResult = `📋 تحليل العقد/المستند\n\n🔴 بنود تعسفية محتملة:\n• البند الخامس: شرط جزائي مبالغ فيه (٥٠٪ من قيمة العقد) — يخالف المادة ٢٢٤ من القانون المدني\n• البند الثامن: تنازل عن حق التقاضي — باطل وفقاً للمادة ١٩٩ من الدستور\n\n🟡 ملاحظات تحتاج مراجعة:\n• البند الثالث: مدة العقد غير محددة بشكل واضح\n• البند السادس: آلية فض النزاعات غير مفصلة\n\n🟢 بنود سليمة:\n• البند الأول: تعريف الأطراف واضح ومحدد\n• البند الثاني: محل العقد معين تعييناً كافياً\n\n💡 صياغات بديلة مقترحة:\n١. البند الخامس: تخفيض الشرط الجزائي إلى نسبة معقولة (١٠-١٥٪)\n٢. البند الثامن: حذف شرط التنازل عن التقاضي واستبداله بشرط تحكيم\n\n⚠️ هذا تحليل أولي وليس رأياً قانونياً ملزماً.`;
      setResult(mockResult);
      addAnalysis({
        personality: "consultant",
        personalityTitle: "محامي استشاري",
        fileName: file || undefined,
        query: query.substring(0, 100),
        results: mockResult,
      });
      setIsLoading(false);
    }, 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFileName(file.name);
      setTextInput(`[محتوى مستخرج من الملف: ${file.name}]\n\nنص تجريبي للعقد يحتوي على بنود متعددة للتحليل...`);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-dark">
      <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/dashboard")} className="p-2 rounded-lg hover:bg-secondary transition-colors">
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <div className="w-9 h-9 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Scale className="w-4 h-4 text-background" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg">🧑‍⚖️</span>
                <h1 className="font-bold font-cairo text-foreground">محامي استشاري</h1>
              </div>
              <p className="text-xs text-muted-foreground">المستشار AI • رصيد: {user?.credits} تحليلات</p>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
          {!result ? (
            <div className="animate-fade-in-up">
              {/* Camera Modal */}
              {showCamera && (
                <div className="fixed inset-0 z-50 bg-background/90 flex flex-col items-center justify-center p-4">
                  <div className="w-full max-w-lg rounded-xl overflow-hidden border border-border bg-card">
                    <div className="flex items-center justify-between p-3 border-b border-border">
                      <h3 className="font-bold font-cairo text-foreground text-sm">📷 التقاط صورة المستند</h3>
                      <button onClick={stopCamera} className="p-1 rounded-lg hover:bg-secondary">
                        <X className="w-5 h-5 text-muted-foreground" />
                      </button>
                    </div>
                    <video ref={videoRef} autoPlay playsInline className="w-full aspect-video bg-secondary" />
                    <div className="p-3 flex justify-center">
                      <Button onClick={capturePhoto} className="bg-gradient-gold text-background font-semibold px-8">
                        <Camera className="w-4 h-4 ml-2" />
                        التقاط
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {cameraError && (
                <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm text-center mb-4">
                  {cameraError}
                </div>
              )}

              <Tabs defaultValue="text" dir="rtl">
                <TabsList className="w-full bg-secondary border border-border">
                  <TabsTrigger value="text" className="flex-1 gap-2">
                    <FileText className="w-4 h-4" /> إدخال نص
                  </TabsTrigger>
                  <TabsTrigger value="file" className="flex-1 gap-2">
                    <Upload className="w-4 h-4" /> رفع ملف
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="text" className="mt-4">
                  <textarea
                    value={textInput}
                    onChange={(e) => setTextInput(e.target.value)}
                    placeholder="الصق نص العقد أو المستند القانوني هنا للتحليل..."
                    rows={12}
                    className="w-full rounded-xl bg-secondary border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
                  />
                </TabsContent>

                <TabsContent value="file" className="mt-4">
                  <div className="rounded-xl border-2 border-dashed border-border bg-secondary/50 p-8 text-center">
                    <Upload className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                    <p className="text-sm text-muted-foreground mb-2">اسحب الملف هنا أو اضغط للاختيار</p>
                    <p className="text-xs text-muted-foreground mb-4">PDF, DOCX, TXT, JPG, PNG (حتى ١٠ ميجا)</p>
                    <input type="file" accept=".pdf,.docx,.txt,.jpg,.jpeg,.png" onChange={handleFileChange} className="hidden" id="file-upload" />
                    <label htmlFor="file-upload">
                      <Button variant="outline" asChild className="cursor-pointer">
                        <span>اختر ملفاً</span>
                      </Button>
                    </label>
                    {fileName && (
                      <p className="mt-3 text-sm text-primary font-medium">📎 {fileName}</p>
                    )}
                  </div>
                  <div className="mt-3 flex justify-center">
                    <Button variant="outline" size="sm" className="gap-2" onClick={startCamera}>
                      <Camera className="w-4 h-4" /> التقاط صورة بالكاميرا
                    </Button>
                  </div>
                </TabsContent>
              </Tabs>

              <Button
                onClick={() => handleAnalyze(textInput, fileName)}
                disabled={!textInput.trim() || isLoading}
                className="w-full mt-4 bg-gradient-gold text-background font-semibold h-12"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
                    جارٍ التحليل...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Send className="w-4 h-4" /> تحليل المستند
                  </div>
                )}
              </Button>
            </div>
          ) : (
            <div className="animate-fade-in-up">
              <div className="rounded-xl bg-card border border-border p-6">
                <h2 className="text-lg font-bold font-cairo text-foreground mb-4 flex items-center gap-2">
                  📋 نتيجة التحليل
                </h2>
                <pre className="text-sm text-foreground leading-relaxed whitespace-pre-wrap font-cairo">{result}</pre>
              </div>
              <div className="flex gap-3 mt-4">
                <Button onClick={() => { setResult(""); setTextInput(""); setFileName(""); }} variant="outline" className="flex-1">
                  تحليل جديد
                </Button>
                <Button onClick={() => navigate("/dashboard")} className="flex-1 bg-gradient-gold text-background">
                  العودة للوحة التحكم
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
      <Disclaimer />
    </div>
  );
};

export default Consultant;
