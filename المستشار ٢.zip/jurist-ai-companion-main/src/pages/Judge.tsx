import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Scale, Send } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Disclaimer from "@/components/Disclaimer";

const caseTypes = ["مدني", "جنائي", "أسرة", "إداري", "عمالي"];

const Judge = () => {
  const navigate = useNavigate();
  const { user, useCredit, addAnalysis } = useAuth();
  const [caseType, setCaseType] = useState("");
  const [facts, setFacts] = useState("");
  const [parties, setParties] = useState("");
  const [evidence, setEvidence] = useState("");
  const [circumstances, setCircumstances] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState("");

  const handleAnalyze = () => {
    if (!caseType || !facts.trim()) return;
    if (!useCredit()) {
      setResult("⚠️ رصيدك منتهي.");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      const mockResult = `👨‍⚖️ تحليل القاضي الافتراضي\n\nنوع القضية: ${caseType}\n\n📋 ملخص الوقائع المعروضة:\n${facts.substring(0, 200)}...\n\n⚖️ التكييف القانوني:\nبناءً على الوقائع المعروضة، تُكيّف هذه القضية باعتبارها...\n\n📖 النصوص القانونية المنطبقة:\n• المادة ١٦٣ من القانون المدني (المسؤولية التقصيرية)\n• المادة ١٧٠ (تقدير التعويض)\n• المادة ٢٢١ (التعويض عن الضرر)\n\n📊 تقدير الحكم المتوقع:\n• احتمال الحكم لصالح المدعي: ٦٥٪\n• نطاق التعويض المتوقع: ٥٠,٠٠٠ - ١٥٠,٠٠٠ جنيه\n• المدة المتوقعة للفصل: ٦-١٢ شهر\n\n📌 سوابق قضائية مشابهة:\n• الطعن رقم ١٢٣٤ لسنة ٨٧ ق - محكمة النقض\n• الطعن رقم ٥٦٧٨ لسنة ٩٠ ق - محكمة النقض\n\n⚠️ هذا تقدير احتمالي وليس حكماً قضائياً ملزماً.`;
      setResult(mockResult);
      addAnalysis({
        personality: "judge",
        personalityTitle: "قاضي افتراضي",
        query: `${caseType}: ${facts.substring(0, 80)}`,
        results: mockResult,
      });
      setIsLoading(false);
    }, 2500);
  };

  const fieldClass = "w-full rounded-xl bg-secondary border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none";

  return (
    <div className="min-h-screen flex flex-col bg-gradient-dark">
      <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/dashboard")} className="p-2 rounded-lg hover:bg-secondary transition-colors">
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <div className="w-9 h-9 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Scale className="w-4 h-4 text-background" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg">👨‍⚖️</span>
                <h1 className="font-bold font-cairo text-foreground">قاضي افتراضي</h1>
              </div>
              <p className="text-xs text-muted-foreground">المستشار AI • رصيد: {user?.credits} تحليلات</p>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-4">
          {!result ? (
            <div className="animate-fade-in-up space-y-4">
              <div className="rounded-xl bg-card border border-border p-6 space-y-4">
                <h2 className="text-sm font-bold font-cairo text-foreground flex items-center gap-2">
                  👨‍⚖️ بيانات القضية
                </h2>

                <div className="space-y-2">
                  <label className="text-xs text-foreground font-medium">نوع القضية *</label>
                  <select
                    value={caseType}
                    onChange={(e) => setCaseType(e.target.value)}
                    className={fieldClass}
                  >
                    <option value="">اختر نوع القضية</option>
                    {caseTypes.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-foreground font-medium">ملخص الوقائع *</label>
                  <textarea rows={5} value={facts} onChange={(e) => setFacts(e.target.value)} placeholder="اذكر ملخصاً واضحاً لوقائع القضية..." className={fieldClass} />
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-foreground font-medium">الأطراف</label>
                  <Input value={parties} onChange={(e) => setParties(e.target.value)} placeholder="المدعي: ... | المدعى عليه: ..." className="bg-secondary border-border" />
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-foreground font-medium">الأدلة المقدمة</label>
                  <textarea rows={3} value={evidence} onChange={(e) => setEvidence(e.target.value)} placeholder="اذكر الأدلة والمستندات المتوفرة..." className={fieldClass} />
                </div>

                <div className="space-y-2">
                  <label className="text-xs text-foreground font-medium">ظروف مخففة أو مشددة (اختياري)</label>
                  <textarea rows={2} value={circumstances} onChange={(e) => setCircumstances(e.target.value)} placeholder="أي ظروف خاصة بالقضية..." className={fieldClass} />
                </div>
              </div>

              <Button
                onClick={handleAnalyze}
                disabled={!caseType || !facts.trim() || isLoading}
                className="w-full bg-gradient-gold text-background font-semibold h-12"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
                    جارٍ تحليل القضية...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Send className="w-4 h-4" /> تحليل القضية
                  </div>
                )}
              </Button>
            </div>
          ) : (
            <div className="animate-fade-in-up">
              <div className="rounded-xl bg-card border border-border p-6">
                <pre className="text-sm text-foreground leading-relaxed whitespace-pre-wrap font-cairo">{result}</pre>
              </div>
              <div className="flex gap-3 mt-4">
                <Button onClick={() => { setResult(""); setFacts(""); setCaseType(""); setParties(""); setEvidence(""); setCircumstances(""); }} variant="outline" className="flex-1">قضية جديدة</Button>
                <Button onClick={() => navigate("/dashboard")} className="flex-1 bg-gradient-gold text-background">العودة للوحة التحكم</Button>
              </div>
            </div>
          )}
        </div>
      </div>
      <Disclaimer />
    </div>
  );
};

export default Judge;
