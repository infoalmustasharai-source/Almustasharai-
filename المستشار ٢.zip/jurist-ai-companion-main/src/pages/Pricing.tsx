import { useNavigate } from "react-router-dom";
import { Scale, Check, ArrowRight, Crown, Zap, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/lib/auth";

const plans = [
  {
    id: "free",
    name: "مجاني",
    price: "٠",
    period: "للأبد",
    icon: <Zap className="w-6 h-6" />,
    credits: "٣ تحليلات",
    description: "للتجربة والاطلاع",
    features: [
      "٣ تحليلات مجانية",
      "الشخصيات الأربع متاحة",
      "تحليل نصي فقط",
      "حفظ النتائج مؤقتاً",
    ],
    cta: "ابدأ مجاناً",
    popular: false,
    gradient: "from-muted to-secondary",
  },
  {
    id: "basic",
    name: "أساسي",
    price: "٤٩",
    period: "جنيه / شهرياً",
    icon: <Star className="w-6 h-6" />,
    credits: "٥٠ تحليل",
    description: "للمحامين والأفراد",
    features: [
      "٥٠ تحليل شهرياً",
      "جميع الشخصيات الأربع",
      "رفع ملفات PDF و DOCX",
      "حفظ سجل التحليلات",
      "تقارير مفصلة قابلة للتصدير",
      "دعم فني عبر البريد",
    ],
    cta: "اشترك الآن",
    popular: true,
    gradient: "from-primary to-accent",
  },
  {
    id: "pro",
    name: "احترافي",
    price: "١٤٩",
    period: "جنيه / شهرياً",
    icon: <Crown className="w-6 h-6" />,
    credits: "غير محدود",
    description: "لمكاتب المحاماة",
    features: [
      "تحليلات غير محدودة",
      "جميع الشخصيات الأربع",
      "رفع جميع أنواع الملفات",
      "OCR للصور العربية",
      "API للتكامل الخارجي",
      "أولوية في الدعم الفني",
      "تقارير متقدمة مع رسوم بيانية",
      "إمكانية إضافة مستخدمين فرعيين",
    ],
    cta: "اشترك الآن",
    popular: false,
    gradient: "from-accent to-primary",
  },
];

const Pricing = () => {
  const navigate = useNavigate();
  const { user } = useAuth();

  return (
    <div className="min-h-screen flex flex-col bg-gradient-dark">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate(-1)} className="p-2 rounded-lg hover:bg-secondary transition-colors">
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <div className="w-9 h-9 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Scale className="w-4 h-4 text-background" />
            </div>
            <h1 className="font-bold font-cairo text-foreground">باقات الاشتراك</h1>
          </div>
        </div>
      </header>

      <div className="flex-1">
        <div className="max-w-6xl mx-auto px-4 py-12">
          {/* Title */}
          <div className="text-center mb-12 animate-fade-in-up">
            <h2 className="text-3xl md:text-4xl font-bold font-cairo text-foreground mb-3">
              اختر الباقة المناسبة لك
            </h2>
            <p className="text-muted-foreground max-w-xl mx-auto">
              ابدأ مجاناً بـ ٣ تحليلات، أو اشترك في إحدى الباقات للحصول على مزايا أكثر
            </p>
          </div>

          {/* Plans Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {plans.map((plan, i) => (
              <div
                key={plan.id}
                className={`relative rounded-2xl p-6 transition-all animate-fade-in-up ${
                  plan.popular
                    ? "bg-card border-2 border-primary shadow-gold scale-[1.02]"
                    : "bg-card border border-border hover:border-primary/30"
                }`}
                style={{ animationDelay: `${i * 150}ms` }}
              >
                {plan.popular && (
                  <div className="absolute -top-3 right-1/2 translate-x-1/2 px-4 py-1 rounded-full bg-gradient-gold text-background text-xs font-bold">
                    الأكثر شعبية ⭐
                  </div>
                )}

                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${
                  plan.popular ? "bg-primary/20 text-primary" : "bg-secondary text-muted-foreground"
                }`}>
                  {plan.icon}
                </div>

                <h3 className="text-xl font-bold font-cairo text-foreground">{plan.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{plan.description}</p>

                <div className="flex items-baseline gap-1 mb-1">
                  <span className="text-4xl font-bold text-gradient-gold font-cairo">{plan.price}</span>
                  <span className="text-sm text-muted-foreground">{plan.period}</span>
                </div>
                <p className="text-sm text-primary font-semibold mb-6">{plan.credits}</p>

                <Button
                  onClick={() => {
                    if (!user) navigate("/register");
                  }}
                  className={`w-full mb-6 ${
                    plan.popular
                      ? "bg-gradient-gold text-background font-semibold hover:opacity-90"
                      : "bg-secondary text-foreground hover:bg-secondary/80 border border-border"
                  }`}
                >
                  {plan.cta}
                </Button>

                <ul className="space-y-3">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm">
                      <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${plan.popular ? "text-primary" : "text-muted-foreground"}`} />
                      <span className="text-foreground">{f}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          {/* FAQ */}
          <div className="mt-16 max-w-2xl mx-auto animate-fade-in-up" style={{ animationDelay: "600ms" }}>
            <h3 className="text-xl font-bold font-cairo text-foreground text-center mb-8">أسئلة شائعة</h3>
            <div className="space-y-4">
              {[
                { q: "هل يمكنني تغيير الباقة لاحقاً؟", a: "نعم، يمكنك الترقية أو تغيير الباقة في أي وقت من لوحة التحكم." },
                { q: "ماذا يحدث عند نفاد الرصيد؟", a: "سيتم إعلامك قبل نفاد الرصيد. يمكنك شراء رصيد إضافي أو الترقية لباقة أعلى." },
                { q: "هل البيانات آمنة؟", a: "نعم، جميع البيانات مشفرة وآمنة تماماً. لا نشارك أي بيانات مع أطراف ثالثة." },
                { q: "هل يمكن استرداد المبلغ؟", a: "نعم، يمكنك استرداد المبلغ خلال ٧ أيام من الاشتراك إذا لم تكن راضياً." },
              ].map((faq) => (
                <div key={faq.q} className="rounded-xl bg-card border border-border p-4">
                  <h4 className="text-sm font-bold text-foreground mb-2">{faq.q}</h4>
                  <p className="text-sm text-muted-foreground">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pricing;
