import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowRight, Scale, Send } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import Disclaimer from "@/components/Disclaimer";

const PLACEHOLDER = `اكتب تفاصيل القضية هنا:

📌 ملخص الوقائع:
[اذكر ملخصاً واضحاً للوقائع]

👥 الأطراف:
- المدعي/المشتكي: 
- المدعى عليه/المشتكى به: 

⚖️ الاتهامات أو المطالب:
[حدد الاتهامات الجنائية أو المطالب المدنية]

📎 الأدلة المتاحة:
[اذكر الأدلة والمستندات المتوفرة]

📝 ملاحظات إضافية:
[أي تفاصيل أخرى مهمة]`;

const Defense = () => {
  const navigate = useNavigate();
  const { user, useCredit, addAnalysis } = useAuth();
  const [content, setContent] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState("");

  const handleAnalyze = () => {
    if (!content.trim()) return;
    if (!useCredit()) {
      setResult("⚠️ رصيدك منتهي. يرجى شراء رصيد إضافي للاستمرار.");
      return;
    }
    setIsLoading(true);
    setTimeout(() => {
      const mockResult = `📝 مذكرة دفاع\n\nبسم الله الرحمن الرحيم\n\nمذكرة بدفاع/ ........................ (المتهم/المدعى عليه)\n\nأولاً: الوقائع\nحيث إن الوقائع تتلخص في أن...\n\nثانياً: الدفوع القانونية\n١. الدفع ببطلان إجراءات القبض والتفتيش:\nحيث إن المادة ٤١ من الدستور المصري تنص على أن الحرية الشخصية حق طبيعي...\n\n٢. الدفع بانتفاء القصد الجنائي:\nالمقرر قانوناً أن القصد الجنائي ركن من أركان الجريمة...\n\n٣. الدفع بعدم كفاية الأدلة:\nمن المستقر عليه فقهاً وقضاءً أن الأحكام الجنائية تبنى على الجزم واليقين...\n\nثالثاً: الطلبات\nلذلك نلتمس من عدالة المحكمة:\nأصلياً: القضاء ببراءة المتهم مما نسب إليه\nاحتياطياً: استعمال أقصى درجات الرأفة\n\n⚠️ هذه مسودة أولية تحتاج مراجعة محامٍ متخصص.`;
      setResult(mockResult);
      addAnalysis({
        personality: "defense",
        personalityTitle: "محامي دفاع",
        query: content.substring(0, 100),
        results: mockResult,
      });
      setIsLoading(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-dark">
      <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => navigate("/dashboard")} className="p-2 rounded-lg hover:bg-secondary transition-colors">
              <ArrowRight className="w-5 h-5 text-muted-foreground" />
            </button>
            <div className="w-9 h-9 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Scale className="w-4 h-4 text-background" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-lg">⚖️</span>
                <h1 className="font-bold font-cairo text-foreground">محامي دفاع</h1>
              </div>
              <p className="text-xs text-muted-foreground">المستشار AI • رصيد: {user?.credits} تحليلات</p>
            </div>
          </div>
        </div>
      </header>

      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-4">
          {!result ? (
            <div className="animate-fade-in-up space-y-4">
              <div className="rounded-xl bg-card border border-border p-4">
                <h2 className="text-sm font-bold font-cairo text-foreground mb-2 flex items-center gap-2">
                  ⚖️ محرر المذكرات القانونية
                </h2>
                <p className="text-xs text-muted-foreground mb-3">اكتب تفاصيل القضية بالتنسيق أدناه وسأقوم بصياغة مذكرة دفاع احترافية</p>
              </div>
              <textarea
                value={content}
                onChange={(e) => setContent(e.target.value)}
                placeholder={PLACEHOLDER}
                rows={16}
                className="w-full rounded-xl bg-secondary border border-border px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none leading-relaxed"
              />
              <Button
                onClick={handleAnalyze}
                disabled={!content.trim() || isLoading}
                className="w-full bg-gradient-gold text-background font-semibold h-12"
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-background border-t-transparent rounded-full animate-spin" />
                    جارٍ صياغة المذكرة...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Send className="w-4 h-4" /> صياغة مذكرة الدفاع
                  </div>
                )}
              </Button>
            </div>
          ) : (
            <div className="animate-fade-in-up">
              <div className="rounded-xl bg-card border border-border p-6">
                <h2 className="text-lg font-bold font-cairo text-foreground mb-4">📝 مذكرة الدفاع</h2>
                <pre className="text-sm text-foreground leading-relaxed whitespace-pre-wrap font-cairo">{result}</pre>
              </div>
              <div className="flex gap-3 mt-4">
                <Button onClick={() => { setResult(""); setContent(""); }} variant="outline" className="flex-1">تحليل جديد</Button>
                <Button onClick={() => navigate("/dashboard")} className="flex-1 bg-gradient-gold text-background">العودة للوحة التحكم</Button>
              </div>
            </div>
          )}
        </div>
      </div>
      <Disclaimer />
    </div>
  );
};

export default Defense;
