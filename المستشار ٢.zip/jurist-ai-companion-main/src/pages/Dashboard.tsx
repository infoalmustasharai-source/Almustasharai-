import { useNavigate } from "react-router-dom";
import { Scale, LogOut, CreditCard, FileText, Plus, Eye, Settings, Shield } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { personalities } from "@/lib/personalities";

const personalityTitleMap: Record<string, string> = {
  consultant: "🧑‍⚖️ محامي استشاري",
  defense: "⚖️ محامي دفاع",
  judge: "👨‍⚖️ قاضي افتراضي",
  analyst: "📊 محلل قانوني",
};

const Dashboard = () => {
  const { user, logout, analyses } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-dark">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-gold flex items-center justify-center">
              <Scale className="w-4 h-4 text-background" />
            </div>
            <div>
              <h1 className="font-bold font-cairo text-foreground">لوحة التحكم</h1>
              <p className="text-xs text-muted-foreground">مرحباً، {user.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {user.role === "admin" && (
              <Button variant="ghost" size="icon" onClick={() => navigate("/admin")} title="لوحة الإدارة">
                <Settings className="w-4 h-4 text-muted-foreground" />
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => { logout(); navigate("/"); }} className="text-muted-foreground">
              <LogOut className="w-4 h-4 ml-1" />
              خروج
            </Button>
          </div>
        </div>
      </header>

      <div className="flex-1">
        <div className="max-w-6xl mx-auto px-4 py-6 space-y-6">
          {/* Credits & Info */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 animate-fade-in-up">
            <div className="p-5 rounded-xl bg-card border border-border">
              <div className="flex items-center gap-3 mb-2">
                <CreditCard className="w-5 h-5 text-primary" />
                <span className="text-sm text-muted-foreground">الرصيد المتبقي</span>
              </div>
              <div className="text-3xl font-bold text-foreground font-cairo">{user.credits}</div>
              <p className="text-xs text-muted-foreground mt-1">تحليلات متاحة</p>
            </div>
            <div className="p-5 rounded-xl bg-card border border-border">
              <div className="flex items-center gap-3 mb-2">
                <FileText className="w-5 h-5 text-primary" />
                <span className="text-sm text-muted-foreground">التحليلات</span>
              </div>
              <div className="text-3xl font-bold text-foreground font-cairo">{analyses.length}</div>
              <p className="text-xs text-muted-foreground mt-1">تحليل مكتمل</p>
            </div>
            <div className="p-5 rounded-xl bg-card border border-border">
              <div className="flex items-center gap-3 mb-2">
                <Shield className="w-5 h-5 text-primary" />
                <span className="text-sm text-muted-foreground">نوع الحساب</span>
              </div>
              <div className="text-lg font-bold text-foreground font-cairo">
                {user.role === "admin" ? "مالك النظام" : user.role === "contributor" ? "مساهم" : "مستخدم"}
              </div>
              <p className="text-xs text-muted-foreground mt-1" dir="ltr">{user.email}</p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="animate-fade-in-up" style={{ animationDelay: "150ms" }}>
            <h2 className="text-lg font-bold font-cairo text-foreground mb-4">تحليل جديد</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {personalities.map((p) => (
                <button
                  key={p.id}
                  onClick={() => navigate(`/chat/${p.id}`)}
                  className="p-4 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-gold transition-all text-right group"
                >
                  <div className="text-3xl mb-2">{p.icon}</div>
                  <div className="text-sm font-bold font-cairo text-foreground group-hover:text-primary transition-colors">{p.title}</div>
                  <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{p.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Analysis History */}
          <div className="animate-fade-in-up" style={{ animationDelay: "300ms" }}>
            <h2 className="text-lg font-bold font-cairo text-foreground mb-4">سجل التحليلات</h2>
            {analyses.length === 0 ? (
              <div className="rounded-xl bg-card border border-border p-8 text-center">
                <FileText className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground text-sm">لم تقم بأي تحليل بعد</p>
                <Button onClick={() => navigate("/")} className="mt-4 bg-gradient-gold text-background">
                  <Plus className="w-4 h-4 ml-1" />
                  ابدأ أول تحليل
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {analyses.slice().reverse().map((a) => (
                  <div key={a.id} className="rounded-xl bg-card border border-border p-4 hover:border-primary/20 transition-colors">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-sm font-medium text-foreground">{personalityTitleMap[a.personality] || a.personalityTitle}</span>
                          {a.fileName && <span className="text-xs text-muted-foreground">• {a.fileName}</span>}
                        </div>
                        <p className="text-xs text-muted-foreground line-clamp-2">{a.query}</p>
                        <p className="text-xs text-muted-foreground mt-1" dir="ltr">
                          {new Date(a.createdAt).toLocaleDateString("ar-EG", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                      <Button variant="ghost" size="icon" className="flex-shrink-0" title="عرض التقرير">
                        <Eye className="w-4 h-4 text-muted-foreground" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
