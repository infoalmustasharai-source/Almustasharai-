import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Scale, UserPlus } from "lucide-react";
import { useAuth } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const Register = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const { register } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (password.length < 6) {
      setError("كلمة المرور يجب أن تكون ٦ أحرف على الأقل");
      return;
    }
    setLoading(true);
    const result = await register(name, email, password);
    setLoading(false);
    if (result.success) {
      navigate("/dashboard");
    } else {
      setError(result.error || "حدث خطأ");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-dark px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8 animate-fade-in-up">
          <div className="w-16 h-16 rounded-2xl bg-gradient-gold flex items-center justify-center mx-auto mb-4">
            <Scale className="w-8 h-8 text-background" />
          </div>
          <h1 className="text-2xl font-bold font-cairo text-foreground">المستشار AI</h1>
          <p className="text-muted-foreground text-sm mt-1">إنشاء حساب جديد</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4 animate-fade-in-up" style={{ animationDelay: "150ms" }}>
          <div className="rounded-xl bg-card border border-border p-6 space-y-4">
            {error && (
              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20 text-destructive text-sm text-center">
                {error}
              </div>
            )}
            <div className="space-y-2">
              <label className="text-sm text-foreground font-medium">الاسم الكامل</label>
              <Input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="أدخل اسمك"
                required
                className="bg-secondary border-border"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-foreground font-medium">البريد الإلكتروني</label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="example@email.com"
                dir="ltr"
                required
                className="bg-secondary border-border"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm text-foreground font-medium">كلمة المرور</label>
              <Input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="٦ أحرف على الأقل"
                dir="ltr"
                required
                className="bg-secondary border-border"
              />
            </div>
            <Button type="submit" disabled={loading} className="w-full bg-gradient-gold text-background font-semibold hover:opacity-90">
              <UserPlus className="w-4 h-4 ml-2" />
              {loading ? "جارٍ الإنشاء..." : "إنشاء حساب"}
            </Button>
            <p className="text-xs text-muted-foreground text-center">
              ستحصل على <span className="text-primary font-semibold">٣ تحليلات مجانية</span> عند التسجيل
            </p>
          </div>
          <p className="text-center text-sm text-muted-foreground">
            لديك حساب بالفعل؟{" "}
            <Link to="/login" className="text-primary hover:underline font-medium">تسجيل الدخول</Link>
          </p>
        </form>
      </div>
    </div>
  );
};

export default Register;
